package com.mir.ems.profile.emap.v2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.mir.ems.globalVar.global;
import com.mir.ems.mqtt.Mqtt;
import com.mir.ems.mqtt.Mqtt2;
import com.mir.ems.mqtt.Publishing;
import com.mir.ems.price.PriceFileReader;
import com.mir.ems.price.RealTimePriceFileReader;

public class TestMain {

	public static void main(String[] args) throws JSONException, ParseException, MqttException {
		// TODO Auto-generated method stub

		/*
		 * ===============================ConnectRegistration
		 */

		// com.mir.ems.profile.emap.v2.ConnectRegistration connectR = new
		// com.mir.ems.profile.emap.v2.ConnectRegistration();
		// connectR.setDestEMA(destEMA);
		// connectR.setRequestID(requestID);
		// connectR.setService(service);
		// connectR.setSrcEMA(srcEMA);
		// connectR.setTime(time);
		// connectR.setVersion(version);
		//

		/*
		 * ===============================ConnectedPartyRegistration
		 */
		 Transports tr = new
		 Transports().addTransportNameParams("MQTT").addTransportNameParams("HTTP");
		 System.out.println(tr.getTransportNameParams());
		
		 Profile p = new Profile().addProfileParams("EMAP2.0B",
		 tr.getTransportNameParams())
		 .addProfileParams("OpenADR2.0b", tr.getTransportNameParams());
		
		 System.out.println(p.toString());
		
		 com.mir.ems.profile.emap.v2.ConnectedPartyRegistration cr = new
		 com.mir.ems.profile.emap.v2.ConnectedPartyRegistration();
		
		 cr.setDestEMA("HYUNJIN");
		 cr.setDuration("PT2S");
		 cr.setProfile(p.getProfileParams());
		 cr.setRequestID("REQUESTID");
		 cr.setResponseCode(200);
		 cr.setResponseDescription("OK");
		 cr.setService("SERVICE");
		 cr.setSrcEMA("SRCEMA");
		 cr.setTime(new Date(System.currentTimeMillis()).toString());
		 cr.setVersion("VERSION");
		
		 System.out.println(cr.toString());
		
		 JSONObject aa = new JSONObject(cr.toString());
		
		 System.out.println(aa);

		//
		// /*
		// * ===============================CreatePartyRegistration
		// */
		// com.mir.ems.profile.emap.v2.CreatePartyRegistration cp = new
		// com.mir.ems.profile.emap.v2.CreatePartyRegistration();
		//
		// cp.setDestEMA("destEMA");
		// cp.setHttpPullModel(false);
		// cp.setProfileName("profilename");
		// cp.setReportOnly(false);
		// cp.setRequestID("requestID");
		// cp.setService("service");
		// cp.setSrcEMA("srcEMA");
		// cp.setTime("time");
		// cp.setTransportName("transportName");
		// cp.setXmlSignature(true);
		//
		// System.out.println(cp.toString());
		//
		// JSONObject aa = new JSONObject(cp.toString());
		// System.out.println(aa.getString("time"));
		//
		// /*
		// * ===============================CreatedPartyRegistration
		// */
		// com.mir.ems.profile.emap.v2.CreatedPartyRegistration cdp = new
		// com.mir.ems.profile.emap.v2.CreatedPartyRegistration();
		//
		// Transports tr1 = new Transports().addTransportNameParams("MQTT");
		// System.out.println(tr1.getTransportNameParams());
		// Profile p1 = new Profile().addProfileParams("EMAP2.0_Version2",
		// tr1.getTransportNameParams());
		//// System.out.println(p1.toString());
		//
		// cdp.setDestEMA("HYUNJIN");
		// cdp.setDuration("PT2S");
		// cdp.setProfile(p1.toString());
		// cdp.setRequestID("REQUESTID");
		// cdp.setResponseCode(200);
		// cdp.setResponseDescription("OK");
		// cdp.setService("SERVICE");
		// cdp.setSrcEMA("SRCEMA");
		// cdp.setTime(new Date(System.currentTimeMillis()).toString());
		// cdp.setVersion("VERSION");
		// cdp.setRegistrationID("registrationID");
		//
		// System.out.println(cdp.toString().replaceAll(Pattern.quote("\\"),
		// ""));
		//
		// /*
		// * ===============================RegisterReport (CLIENT EMA -->
		// SERVER
		// * EMA)
		// */
		//
		// PowerAttributes pa = new PowerAttributes();
		// pa.addPowerAttributesParams(200.1, 300.1, 400.1);
		// pa.addPowerAttributesParams(500.1, 600.1, 700.1);
		//
		// ReportDescription rd = new ReportDescription();
		// rd.addReportDescriptionParams("rid", "resourceID", "deviceType",
		// "reportType", "itemUnits", "siScaleCode",
		// "marketContext", "minPeriod", "maxPeriod", false, "itemDescription",
		// pa.getPowerAttributesParams(),
		// "state", "qos", 100.1, 9, 200.1, 300.1, 400.1, 500.1, 600.1, 800.1,
		// "time", "maxTime", "minTime", 9);
		//
		// Report report = new Report();
		// report.addReportParams("duration", rd.getReportDescriptionParams(),
		// "reportRequestID", "reportSpecifierID",
		// "reportName", "createdDateTime");
		//
		// com.mir.ems.profile.emap.v2.RegisterReport rt = new
		// com.mir.ems.profile.emap.v2.RegisterReport();
		// rt.setDestEMA("destEMA");
		// rt.setReport(report.getReportParams());
		// rt.setRequestID("requestID");
		// rt.setService("service");
		// rt.setSrcEMA("srcEMA");
		// rt.setTime("time");
		//
		// System.out.println("RegisterReport (CLIENT EMA --> SERVER EMA)");
		// System.out.println(rt.toString().replaceAll(Pattern.quote("\\"),
		// ""));
		//
		// JSONObject bb = new JSONObject(rt.toString());
		//
		// JSONArray arr = new JSONArray(bb.getString("report"));
		//
		// System.out.println(arr.length());
		//
		// for (int i = 0; i < arr.length(); i++) {
		//
		// JSONArray decrArr = new JSONArray(new
		// JSONObject(arr.get(i).toString()).getString("reportDescription"));
		//
		// System.out.println(decrArr);
		//
		// for (int j = 0; j < decrArr.length(); j++) {
		//
		// JSONObject decr = new JSONObject(decrArr.get(j).toString());
		//
		//
		// System.out.println("@@@@@@@@@");
		// System.out.println(decr.getString("rID"));
		// System.out.println("@@@@@@@@@");
		//
		// JSONArray powerAtts = new
		// JSONArray(decr.getString("powerAttributes"));
		//
		// for(int k=0; k< powerAtts.length(); k++){
		// JSONObject powerAtt = new JSONObject(powerAtts.get(k).toString());
		// System.out.println(powerAtt.getString("hertz"));
		// }
		//
		//
		// }
		//
		// }
		//
		// //
		// // JSONObject cc = new JSONObject(arr.get(0).toString());
		// //
		// //
		// // JSONArray rptDesc = new JSONArray(new
		// // JSONObject(arr.get(0).toString()).getString("reportDescription"));
		// //
		// // System.out.println(rptDesc.getString("rID"));
		//
		// // JSONObject cc = new JSONObject(new
		// //
		// JSONObject(bb.getString("report")).getString("reportDescription"));
		//
		// // System.out.println(cc.getString("deviceType"));
		//
		// /*
		// * ===============================RegisteredReport
		// */
		//
		// com.mir.ems.profile.emap.v2.RegisteredReport rdt = new
		// com.mir.ems.profile.emap.v2.RegisteredReport();
		// rdt.setDestEMA("destEMA");
		// rdt.setRequestID("requestID");
		// rdt.setResponseCode(200);
		// rdt.setResponseDescription("responseDescription");
		// rdt.setService("service");
		// rdt.setSrcEMA("srcEMA");
		// rdt.setTime("time");
		// rdt.setType("type");
		//
		// System.out.println("RegisteredReport");
		// System.out.println(rdt.toString());
		//
		// /*
		// * ===============================Poll
		// */
		// com.mir.ems.profile.emap.v2.Poll poll = new
		// com.mir.ems.profile.emap.v2.Poll();
		// poll.setDestEMA("destEMA");
		// poll.setService("service");
		// poll.setSrcEMA("srcEMA");
		// poll.setTime("time");
		//
		// System.out.println("POLL");
		// System.out.println(poll.toString());
		//
		// /*
		// * ===============================RegisterReport (SERVER EMA -->
		// CLIENT
		// * EMA)
		// */
		//
		// com.mir.ems.profile.emap.v2.RegisterReport rt2 = new
		// com.mir.ems.profile.emap.v2.RegisterReport();
		// rt2.setSrcEMA("srcEMA");
		// rt2.setDestEMA("destEMA");
		// rt2.setRequestID("requestID");
		// rt2.setService("service");
		// rt2.setTime("time");
		// System.out.println("RegisterReport (SERVER EMA --> CLIENT EMA)");
		// System.out.println(rt2.toString());
		//
		// /*
		// * ===============================Response
		// */
		//
		// com.mir.ems.profile.emap.v2.Response response = new
		// com.mir.ems.profile.emap.v2.Response();
		// response.setDestEMA("destEMA");
		// response.setRequestID("requestID");
		// response.setResponseCode(200);
		// response.setResponseDescription("responseDescription");
		// response.setService("response");
		// response.setSrcEMA("srcEMA");
		// response.setTime("time");
		// System.out.println();
		// System.err.println("RESPONSE");
		// System.out.println(response.toString());
		//
		// /*
		// * ===============================RequestEvent
		// */
		//
		// com.mir.ems.profile.emap.v2.RequestEvent requestEvent = new
		// com.mir.ems.profile.emap.v2.RequestEvent();
		// requestEvent.setDestEMA("destEMA");
		// requestEvent.setRequestID("requestID");
		// requestEvent.setService("RequestEvent");
		// requestEvent.setSrcEMA("srcEMA");
		// requestEvent.setTime("time");
		// System.out.println();
		// System.err.println("requestEvent");
		// System.out.println(requestEvent.toString());

		/*
		 * ===============================DistributeEvent
		 */

//		Intervals interval = new Intervals();
//
//		interval.addIntervalsParams("duration", "uid", 100.1);
//
//		EventSignals es = new EventSignals();
//		Event event = new Event();
//
//		// es.addEventSignalsParams(interval.getIntervalsParams(),
//		// "signalName",
//		// "signalType", "signalID", 200.1, 300.1,
//		// 500.2, 10000, "unit");
//
//		// double price = global.realTimePriceTable.get(i).getPrice();
//
//		System.out.println("@@");
//		System.out.println(new EventSignals().addEventSignalsParams(interval.getIntervalsParams(), "signalName",
//				"Price Event", "signalID", 0, 0, 0, 10.1, "KW/WON").addEventSignalsParams(interval.getIntervalsParams(), "signalName",
//						"Price Event", "signalID", 0, 0, 0, 10.1, "KW/WON").toString());
//
//		event.addEventParams("eventID",
//				new EventSignals().addEventSignalsParams(interval.getIntervalsParams(), "signalName", "Price Event",
//						"signalID", 0, 0, 0, 10.1, "KW/WON").addEventSignalsParams(interval.getIntervalsParams(), "signalName",
//								"Price Event", "signalID", 0, 0, 0, 10.1, "KW/WON").getEventSignalsParams(),
//				1, "modificationReason", 2, "https://hourlypricing.comed.com/live-prices/?date=20180826",
//				new Date(System.currentTimeMillis()).toString(), "eventStatus", global.tableHasChanged,
//				"RealTimePricing", "properties", "components", "specificDestEMA",
//				new Date(System.currentTimeMillis()).toString(), "PT1H", "tolerance", "notification", "rampUp",
//				"recovery");
//
//		System.out.println(event.toString());
//
//		EventResponse er = new EventResponse();
//		er.setRequestID("requestID");
//		er.setResponseCode(200);
//		er.setResponseDescription("responseDescription");
//
//		com.mir.ems.profile.emap.v2.DistributeEvent drE = new com.mir.ems.profile.emap.v2.DistributeEvent();
//
//		drE.setDestEMA("destEMA");
//		drE.setEvent(event.getEventParams());
//		drE.setRequestID("requestID");
//		drE.setResponse(er.toString());
//		drE.setService("service");
//		drE.setSrcEMA("srcEMA");
//		drE.setTime("time");
//		drE.setResponseRequired("responseRequired");
//
//		System.out.println();
//		System.err.println("DistributeEvent");
//		System.out.println(drE.toString());
//
//		JSONObject aa = new JSONObject(drE.toString());
//		System.out.println(aa);
		/*
		 * ===============================UpdateReport (CLIENT EMA --> SERVER
		 * EMA)
		 */

		// PowerAttributes pa1 = new PowerAttributes();
		// pa1.addPowerAttributesParams(200.1, 300.1, 400.1);
		// pa1.addPowerAttributesParams(500.1, 600.1, 700.1);
		//
		// ReportDescription rd1 = new ReportDescription();
		// rd1.addReportDescriptionParams("rid", "resourceID", "deviceType",
		// "reportType", "itemUnits", "siScaleCode",
		// "marketContext", "minPeriod", "maxPeriod", false, "itemDescription",
		// pa1.getPowerAttributesParams(),
		// "state", 100.1, 9, 200.1, 300.1, 400.1, 500.1, 600.1, 800.1, "time",
		// "maxTime", "minTime", 9);
		//
		// Report report1 = new Report();
		// report1.addReportParams("duration", rd1.getReportDescriptionParams(),
		// "reportRequestID", "reportSpecifierID",
		// "reportName", "createdDateTime");
		//
		// com.mir.ems.profile.emap.v2.UpdateReport rt1 = new
		// com.mir.ems.profile.emap.v2.UpdateReport();
		// rt1.setDestEMA("destEMA");
		// rt1.setReport(report1.getReportParams());
		// rt1.setRequestID("requestID");
		// rt1.setService("service");
		// rt1.setSrcEMA("srcEMA");
		// rt1.setTime("time");
		//
		// System.out.println();
		// System.err.println("UpdateReport (CLIENT EMA --> SERVER EMA)");
		// System.out.println(rt1.toString().replaceAll(Pattern.quote("\\"),
		// ""));
		//
		// /*
		// * ===============================UpdatedReport
		// */
		//
		// com.mir.ems.profile.emap.v2.UpdatedReport upR = new
		// com.mir.ems.profile.emap.v2.UpdatedReport();
		// upR.setDestEMA("destEMA");
		// upR.setRequestID("requestID");
		// upR.setResponseCode(200);
		// upR.setResponseDescription("responseDescription");
		// upR.setService("service");
		// upR.setSrcEMA("srcEMA");
		// upR.setTime("time");
		//
		// System.out.println();
		// System.err.println("UpdatedReport ");
		// System.out.println(upR.toString());
		//
		// /*
		// * ===============================CreatedEvent
		// */
		//
		// com.mir.ems.profile.emap.v2.CreatedEvent cde = new
		// com.mir.ems.profile.emap.v2.CreatedEvent();
		//
		// cde.setDestEMA("destEMA");
		// cde.setEventID("eventID");
		// cde.setModificationNumber(1);
		// cde.setOptType("optType");
		// cde.setRequestID("requestID");
		// cde.setResponseCode(200);
		// cde.setResponseDescription("responseDescription");
		// cde.setService("service");
		// cde.setSrcEMA("srcEMA");
		// cde.setTime("time");
		//
		// System.out.println();
		// System.err.println("CreatedEvent ");
		// System.out.println(cde.toString());
		//
		// /*
		// * ===============================CreatOpt
		// */
		//

		//
		//
		// String mqtt4 = "tcp://" + "166.104.28.51" + ":" + "1883";
		//
		// Mqtt2 emapmqttclient = new Mqtt2(mqtt4, "hell1asd233oheASDonil1",
		// false, false, null, null);
		//
		// emapmqttclient.start();
		//
		// System.out.println("Connected to Mqtt Broker" + mqtt4);
		//
		// System.out.println("MQTT SERVER ON!");
		//
		// emapmqttclient.subscribe("/EMAP/CEMA/#", 0);
		//
		//
		// com.mir.ems.profile.emap.v2.Available ava = new
		// com.mir.ems.profile.emap.v2.Available();
		//
		// ava.addEventParams("dtStart", "duration", 200.1, 20180910, 1,
		// 20180910, 1)
		// .addEventParams("dtStart", "duration", 200.1, 20180910, 1, 20180910,
		// 1);
		//
		// com.mir.ems.profile.emap.v2.CreateOpt copt = new
		// com.mir.ems.profile.emap.v2.CreateOpt();
		//
		// copt.setAvailable(ava.getEventParams());
		// copt.setCreatedDateTime("createdDateTime");
		// copt.setDestEMA("SERVER_EMS1");
		// copt.setMarketContext("marketContext");
		// copt.setOptID("optID");
		// copt.setOptReason("optReason");
		// copt.setOptType("optType");
		// copt.setRequestID("requestID");
		// copt.setSrcEMA("ClientEMA2");
		// copt.setService("CreateOpt");
		//
		//
		//
		//
		// System.out.println();
		// System.err.println("CreatedOpt");
		// System.out.println(copt.toString());
		// System.out.println("@@@@@@@@@");
		//
		//
		// new Publishing().publishThread(emapmqttclient.client,
		// "/EMAP/SEMA/1.0b/Opt", 0, copt.toString().getBytes());
		//
		//
		// JSONObject jsonObj = new JSONObject(copt.toString());
		//
		// JSONArray arr = new JSONArray(jsonObj.getString("available"));
		//
		// for(int i=0; i<arr.length(); i++){
		//
		//
		// JSONObject parseArr = new JSONObject(arr.get(i).toString());
		//
		//
		// String strYMD = parseArr.getInt("startYMD") + "";
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		// Date requestDate = sdf.parse(strYMD);
		//
		// System.out.println(requestDate);
		//
		// }
		//

	}

}
